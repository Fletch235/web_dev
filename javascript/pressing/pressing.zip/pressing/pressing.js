function color(col){
  console.log(col)
  document.getElementById(col).style.backgroundColor=col;
}
